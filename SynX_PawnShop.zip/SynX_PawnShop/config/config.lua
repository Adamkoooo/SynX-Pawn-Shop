Config = {}

Config.Locales = "cs" -- "cs" or "en"

Config.Selllocations = {
    vector4(-671.0528, -616.8859, 31.5570, 281.1331), -- Změň na tvoje souřadnice
}

Config.NPCModel = `a_m_m_business_01`

Config.Items = {
    ['burger'] = {
        label = 'Burger',
        price = 100,
    },
    ['water'] = {
        label = 'Water',
        price = 100,
    },
    ['weapon_pistol'] = {
        label = 'Pistol',
        price = 5000,
    },
}