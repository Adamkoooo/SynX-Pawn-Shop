Locales = {
    ['cs'] = {
        open_menu = "Otevřít Pawn Shop",
        shop_title = "Zastavárna",
        sell_items = "Prodat položky",
        sell_menu_title = "Prodejní menu",
        input_title = "Zadejte množství",
        input_label = "Množství k prodeji",
        selling = "Prodáváte položky...",
        item_sold = "Prodali jste %s za $%d.",
        not_enough_items = "Nemáte dostatek položek k prodeji.",
    },
    ['en'] = {
        open_menu = "Open Pawn Shop",
        shop_title = "Pawn Shop",
        sell_items = "Sell Items",
        sell_menu_title = "Selling Menu",
        input_title = "Enter Quantity",
        input_label = "Quantity to sell",
        selling = "Selling items...",
        item_sold = "You sold %s for $%d.",
        not_enough_items = "You don't have enough items to sell.",
    }
}