local locale = Config.Locales

for _, loc in ipairs(Config.Selllocations) do
    local npc = CreatePed(4, Config.NPCModel, loc.x, loc.y, loc.z - 1.0, 0.0, false, true)
    FreezeEntityPosition(npc, true)
    SetEntityInvincible(npc, true)
    SetBlockingOfNonTemporaryEvents(npc, true)
    exports.ox_target:addLocalEntity(npc, {
        {
            name = 'pawn_shop_menu_open',
            icon = 'fas fa-store',
            label = Locales[locale].open_menu,
            onSelect = function()
                lib.showContext('pawn_shop_menu_open')
            end
        }
    })
end

lib.registerContext({
    id = 'pawn_shop_menu_open',
    title = Locales[locale].shop_title,
    options = {
        {
            title = Locales[locale].sell_items,
            menu = 'sell_menu',
            icon = 'fas fa-bars'
        }
    }
})

lib.registerContext({
    id = 'sell_menu',
    title = Locales[locale].sell_menu_title,
    options = (function()
        local options = {}
        for item, data in pairs(Config.Items) do
            table.insert(options, {
                title = data.label .. ' - $' .. data.price,
                icon = 'fas fa-coins',
                onSelect = function()
                    local input = lib.inputDialog(Locales[locale].input_title, {
                        { type = 'number', label = Locales[locale].input_label, default = 1, min = 1 }
                    })
                    if input and input[1] then
                        local amount = tonumber(input[1])
                        if amount > 0 then
                            lib.progressBar({
                                duration = 3000,
                                label = Locales[locale].selling,
                                useWhileDead = false,
                                canCancel = false,
                                disable = { car = true, move = true, combat = true },
                            })
                            TriggerServerEvent('pawnshop:sellItem', item, amount)
                        end
                    end
                end
            })
        end
        return options
    end)()
})