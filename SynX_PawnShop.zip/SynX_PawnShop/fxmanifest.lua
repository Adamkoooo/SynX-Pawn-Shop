fx_version 'cerulean'
game 'gta5'

author 'SynX'
description '[ESX] Pawn Shop Script by SynX'
version '1.0.0'

-- Hlavní soubory
shared_script {
    'config/config.lua',
    'locales/locales.lua'
}

client_scripts {
    '@ox_lib/init.lua',
    'client/client.lua'
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    '@ox_lib/init.lua',
    'server/server.lua'
}

-- Závislosti
dependencies {
    'ox_lib',
    'ox_target',
    'es_extended'
}

lua54 'yes'