ESX = nil
ESX = exports["es_extended"]:getSharedObject()

RegisterNetEvent('pawnshop:sellItem', function(item, amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    local itemData = Config.Items[item]
    if itemData then
        local itemCount = xPlayer.getInventoryItem(item).count
        if itemCount >= amount then
            xPlayer.removeInventoryItem(item, amount)
            xPlayer.addMoney(itemData.price * amount)
            TriggerClientEvent('ox_lib:notify', source, {
                type = 'success',
                description = string.format(Locales[Config.Locales].item_sold, amount, itemData.price * amount)
            })
        else
            TriggerClientEvent('ox_lib:notify', source, {
                type = 'error',
                description = Locales[Config.Locales].not_enough_items
            })
        end
    end
end)